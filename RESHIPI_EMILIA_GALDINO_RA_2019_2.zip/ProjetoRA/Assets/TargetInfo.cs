﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Vuforia;

public class TargetInfo : MonoBehaviour
{
	void OnGUI()
	{
		StateManager sm = TrackerManager.Instance.GetStateManager();

		foreach (TrackableBehaviour tb in sm.GetActiveTrackableBehaviours())
		{
			if(tb is ImageTargetBehaviour)
			{
				ImageTargetBehaviour itb = tb as ImageTargetBehaviour;
				ImageTarget it = itb.Trackable as ImageTarget;

				GUI.color = Color.blue;
				GUI.Label(new Rect(25, 25, 500, 500), it.Name);
			}
		}
	}
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
