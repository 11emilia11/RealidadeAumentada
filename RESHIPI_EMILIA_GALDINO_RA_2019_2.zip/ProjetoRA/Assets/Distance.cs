﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Vuforia;

public class Distance : MonoBehaviour, ITrackableEventHandler
{
	public GameObject ImageOat;
	public GameObject ImageMaisena;
	public float dist;
	private bool isASetOfIngredients = false;
	private bool isDetected = false;


    // Start is called before the first frame update
    void Start()
    {
        GetComponent<TrackableBehaviour>().RegisterTrackableEventHandler(this);
    }

    public void OnTrackableStateChanged(TrackableBehaviour.Status previousStatus, 
    	TrackableBehaviour.Status newStatus)
    {
    	if(newStatus == TrackableBehaviour.Status.DETECTED ||
    	newStatus == TrackableBehaviour.Status.TRACKED || 
    	newStatus == TrackableBehaviour.Status.EXTENDED_TRACKED )

    	{
    		isDetected = true;

    	}

    	else
    	{
    		isDetected = false;
    	}


    }



    void OnGUI()
    {
    	if(isDetected)
    	{
	    		if(isASetOfIngredients)
	    	{
	    		GUI.color = Color.red;
	    		GUI.Label(new Rect(50, 50, 500, 500), "Receitas Sugeridas: ");
	    		GUI.Label(new Rect(50, 70, 500, 500), "Bolo de Banana, Muffin de Aveia, Hambúrguer de Cenoura");

	    	}
    	}
    	

    }


    // Update is called once per frame
    void Update()
    {
        dist = Vector3.Distance(ImageOat.transform.position, ImageMaisena.transform.position);

        if (dist < 15)
        {
        	isASetOfIngredients = true;
        }

        else
        {
        	isASetOfIngredients = false;

        }
       
    }
}
